import 'package:flutter/foundation.dart' show immutable;


@immutable
class Constants {
  static const accoubtExistswithDifferentCrdentual =
      'Account-exists-with-diffrent-credentaiks';

  static const goolgeCom = 'google.com';
  static const emailScope = 'email';

  const Constants._();
}
