enum AuthResults {
  aborted,
  success,
  failure,
}
