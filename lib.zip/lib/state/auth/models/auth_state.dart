import 'package:flutter/foundation.dart' show immutable;
import 'package:instagram_clone/state/auth/models/auth_results.dart';
import 'package:instagram_clone/state/posts/typedefs/user_id.dart';

@immutable
class AuthState {
  final AuthResults? result;
  final bool isLoading;
  final UserId? userId;

  const AuthState({
    required this.result,
    required this.isLoading,
    required this.userId,
  });
}
